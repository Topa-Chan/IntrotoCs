import java.util.Random;
import java.util.Scanner;

/*
 * Tyler Patterson
 *CSC110
 * Todd Nicholes
 */

public class TPA4 {

	static Scanner scan = new Scanner(System.in);
	static Random rand = new Random();

	public static void main(String[] args) {

		
		boolean valid = false;

		do {
			System.out.println("Main Menu");
			System.out.println("1. Calculate the hypotenuse of a right triangle.");
			System.out.println("2. Reverse a message.");
			System.out.println("3. Play High/Low.");
			System.out.println("4. Exit.");
			System.out.print("Make a selection: ");

			int selection = scan.nextInt();
			if (selection == 1) {
				System.out.println();
				System.out.print("Enter side A: ");
				double a = scan.nextInt();
				System.out.print("Enter Side B: ");
				double b = scan.nextInt();
				double c = MyMath.sqrt((MyMath.pow(a, 2) + MyMath.pow(b, 2)));
				System.out.println("The hypotenuse is: " + c);
			}
			if (selection == 2) {
				System.out.println();
				System.out.print("Enter A Message: ");
				MyString myString = new MyString(scan.next());
				System.out.println();
			}
			if (selection == 3) {
				System.out.println();
				System.out.print("Enter the Low and High numbers seperated by a space: ");
				int low = scan.nextInt();
				int high = scan.nextInt();
				int number = rand.nextInt(low) + low;
				boolean chosen = false;
				do {
					System.out.print("Guess A Number: ");
					int guess = scan.nextInt();
					if (guess == number) {
						System.out.println("Right!");
						chosen = true;
					}
					if (guess > number) {
						System.out.println("Too High!");
					}
					if (guess < number) {
						System.out.println("Too Low!");
					}
				} while (!chosen);
				System.out.println(number);
			}
			if (selection == 4) {
				System.out.println();
				System.out.println("Bye!");
				valid = true;
			}
			System.out.println();
		} while (!valid);

		
	}

}
