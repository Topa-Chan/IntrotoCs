
public class TPA5 {

	public static void main(String[] args) {
		
		Bank myBank = new Bank();
		myBank.Bank();
		
	}

}
